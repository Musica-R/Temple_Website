import HistoryBook from "../Components/HistoryBook";
import TempleHistory from "../Components/TempleHistory";
import "../Stylesheet/OurHeritage.css";
import { useLanguage } from "../Context/Languagecontext";        // ← add
import translations from "../Json/Ourheritage.json";            // ← add

export default function OurHeritage() {
    const { language } = useLanguage();                          // ← add
    const t = translations.ourHeritage[language] || translations.ourHeritage["EN"]; // ← add

    return (
        <div>
            <div className="ourheritage">
                <img src="/assets/about.jpg" alt="Temple" className="hero-img" />
                <div className="ourheritage-overlay"></div>
                <div className="ourheritage-content">
                    <span className="hero-tag">{t.heroTag}</span>
                    <h1>{t.heroTitle}</h1>
                    <p className="hero-sub">{t.heroSub}</p>
                    <div className="ourheritage-breadcrumb">
                        <span>{t.breadcrumb.home}</span>
                        <span className="ourheritage-dot">ॐ</span>
                        <span className="ourheritage-active">{t.breadcrumb.active}</span>
                    </div>
                </div>
            </div>

            {/* ── INTRO VERSE BAND ── */}
            <div className="gallery-verse-band">
                <div className="verse-inner">
                    <span className="verse-om">ॐ</span>
                    <p>{t.verse}</p>
                </div>
            </div>

            <TempleHistory />
            <HistoryBook />
        </div>
    );
}