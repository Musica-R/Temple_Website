import React from 'react';
import DonationForm from '../Components/DonationForm';
import { useLanguage } from "../Context/Languagecontext";          // ← add
import translations from "../Json/datatranslation.json";              // ← add

export default function DonationPage() {
  const { language } = useLanguage();                              // ← add
  const t = translations.donationPage[language] || translations.donationPage["EN"]; // ← add

  return (
    <div>
      <div className="ourheritage">
        <img src="/assets/about.jpg" alt="Temple" className="hero-img" />
        <div className="ourheritage-overlay"></div>
        <div className="ourheritage-content">
          <span className="hero-tag">{t.heroTag}</span>
          <h1>{t.heroTitle}</h1>
          <p className="hero-sub">{t.heroSub}</p>
          <div className="ourheritage-breadcrumb">
            <span>{t.breadcrumb.home}</span>
            <span className="ourheritage-dot">ॐ</span>
            <span className="ourheritage-active">{t.breadcrumb.active}</span>
          </div>
        </div>
      </div>

      {/* ── INTRO VERSE BAND ── */}
      <div className="gallery-verse-band">
        <div className="verse-inner">
          <span className="verse-om">ॐ</span>
          <p>{t.verse}</p>
        </div>
      </div>

      <DonationForm />
    </div>
  );
}