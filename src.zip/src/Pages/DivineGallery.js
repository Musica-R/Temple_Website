import "../Stylesheet/DivineGallery.css";
import { useEffect } from "react";
import { useLanguage } from "../Context/Languagecontext";          // ← add
import translations from "../Json/datatranslation.json";              // ← add

export default function DivineGallery() {
    const { language } = useLanguage();                            // ← add
    const t = translations.divineGallery[language] || translations.divineGallery["EN"]; // ← add

    useEffect(() => {
        const items = document.querySelectorAll(".gallery-item");
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("show");
                    }
                });
            },
            { threshold: 0.15 }
        );
        items.forEach((el) => observer.observe(el));
        return () => observer.disconnect();
    }, []);

    return (
        <div>

            {/* ── HERO BANNER ── */}
            <div className="ourheritage">
                <img src="/assets/about.jpg" alt="Temple" className="hero-img" />
                <div className="ourheritage-overlay"></div>
                <div className="ourheritage-content">
                    <span className="hero-tag">{t.heroTag}</span>
                    <h1>{t.heroTitle}</h1>
                    <p className="hero-sub">{t.heroSub}</p>
                    <div className="ourheritage-breadcrumb">
                        <span>{t.breadcrumb.home}</span>
                        <span className="ourheritage-dot">ॐ</span>
                        <span className="ourheritage-active">{t.breadcrumb.active}</span>
                    </div>
                </div>
            </div>

            {/* ── INTRO VERSE BAND ── */}
            <div className="gallery-verse-band">
                <div className="verse-inner">
                    <span className="verse-om">ॐ</span>
                    <p>{t.verse}</p>
                </div>
            </div>

            <section className="divine-gallerys">

                {/* ══ CHAPTER ONE ══ */}
                <div className="chapter-header">
                    <span className="chapter-number">{t.chapter1.number}</span>
                    <div className="chapter-lines">
                        <span></span><i>🪔</i><span></span>
                    </div>
                    <h2 className="chapter-title">{t.chapter1.title}</h2>
                    <p className="chapter-sub">{t.chapter1.sub}</p>
                </div>

                <div className="gallery-layout">
                    {/* LEFT CONTENT */}
                    <div className="gallery-content">
                        <div className="content-badge">{t.contentLeft.badge}</div>
                        <h2>{t.contentLeft.title}</h2>
                        <div className="gallery-divider">ॐ</div>
                        <p>{t.contentLeft.p1}</p>
                        <p>{t.contentLeft.p2}</p>
                        <ul className="content-features">
                            {t.contentLeft.features.map((f, i) => (
                                <li key={i}>{f}</li>
                            ))}
                        </ul>
                        <button className="gallery-btn">{t.contentLeft.btn}</button>
                    </div>

                    {/* RIGHT IMAGES */}
                    <div className="gallery-grid-new">
                        {t.galleryData.slice(0, 6).map((item) => (
                            <div className="gallery-item" key={item.id} data-title={item.title} data-desc={item.desc}>
                                <img src={item.img} alt={item.title} />
                                <div className="item-overlay">
                                    <span className="item-title">{item.title}</span>
                                    <span className="item-desc">{item.desc}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* ── STATS BAND ── */}
                <div className="gallery-stats-band">
                    {t.stats.map((s, i) => (
                        <div className="gstat" key={i}>
                            <span className="gstat-num">{s.num}</span>
                            <span className="gstat-label">{s.label}</span>
                        </div>
                    ))}
                </div>

                {/* ══ CHAPTER TWO ══ */}
                <div className="chapter-header">
                    <span className="chapter-number">{t.chapter2.number}</span>
                    <div className="chapter-lines">
                        <span></span><i>🌸</i><span></span>
                    </div>
                    <h2 className="chapter-title">{t.chapter2.title}</h2>
                    <p className="chapter-sub">{t.chapter2.sub}</p>
                </div>

                <div className="gallery-layout gallery-layout-reverse">
                    <div className="gallery-grid-new">
                        {t.galleryData.slice(7, 13).map((item) => (
                            <div className="gallery-item" key={item.id} data-title={item.title} data-desc={item.desc}>
                                <img src={item.img} alt={item.title} />
                                <div className="item-overlay">
                                    <span className="item-title">{item.title}</span>
                                    <span className="item-desc">{item.desc}</span>
                                </div>
                            </div>
                        ))}
                    </div>

                    <div className="gallery-content">
                        <div className="content-badge">{t.contentRight.badge}</div>
                        <h2>{t.contentRight.title}</h2>
                        <div className="gallery-divider">ॐ</div>
                        <p>{t.contentRight.p1}</p>
                        <p>{t.contentRight.p2}</p>
                        <ul className="content-features">
                            {t.contentRight.features.map((f, i) => (
                                <li key={i}>{f}</li>
                            ))}
                        </ul>
                        <button className="gallery-btn">{t.contentRight.btn}</button>
                    </div>
                </div>

                {/* ── TESTIMONIALS BAND ── */}
                <div className="gallery-testimonials">
                    <div className="testimonial-heading">
                        <div className="chapter-lines"><span></span><i>✦</i><span></span></div>
                        <h3>{t.testimonials.heading}</h3>
                        <p>{t.testimonials.sub}</p>
                    </div>
                    <div className="testimonial-grid">
                        {t.testimonials.list.map((item, i) => (
                            <div className="testimonial-card" key={i}>
                                <p className="t-quote">"{item.text}"</p>
                                <div className="t-author">
                                    <span className="t-name">{item.name}</span>
                                    <span className="t-loc">📍 {item.loc}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* ── BOTTOM CTA STRIP ── */}
                <div className="gallery-cta-strip">
                    <div className="gcta-inner">
                        <span className="gcta-om">🛕</span>
                        <div className="gcta-text">
                            <h3>{t.cta.title}</h3>
                            <p>{t.cta.sub}</p>
                        </div>
                        <div className="gcta-btns">
                            <button className="gcta-btn-primary">{t.cta.btnPrimary}</button>
                            <button className="gcta-btn-secondary">{t.cta.btnSecondary}</button>
                        </div>
                    </div>
                </div>

            </section>
        </div>
    );
}