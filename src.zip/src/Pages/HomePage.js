import Hero from '../Components/Hero'
import Pooja from '../Components/Pooja'
import Section from '../Components/Section'
import Ticker from '../Components/Ticker'
import Timing from '../Components/Timing'

export default function HomePage() {
    return (
        <div>
            <Hero />
            <Ticker />
            <Section />
            <Pooja />
            <Timing />
        </div>
    )
}
