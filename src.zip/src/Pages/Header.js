import "../Stylesheet/Header.css";
import { Link } from "react-router-dom";
import { useState } from "react";
import { useLanguage } from "../Context/Languagecontext";
import translations from "../Json/Reachustranslations.json"; 

export default function Header() {
    const [menuOpen, setMenuOpen] = useState(false);
    const [langOpen, setLangOpen] = useState(false);
    const { language, setLanguage } = useLanguage();

    // ─── Pick the right language block ───────────────────────────────────────
    const t = translations.header[language] || translations.header["EN"];

    const handleLanguageChange = (lang) => {
        setLanguage(lang);
        setLangOpen(false);
        setMenuOpen(false);
    };

    return (
        <nav>
            <div className="nav-inner">

                {/* LOGO — translated */}
                <div className="nav-logo">
                    <div className="logo-text">
                        {t.logoName}
                        <span>{t.logoSubtitle}</span>
                    </div>
                </div>

                {/* HAMBURGER */}
                <div
                    className={`hamburger ${menuOpen ? "active" : ""}`}
                    onClick={() => setMenuOpen(!menuOpen)}
                >
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                {/* NAV LINKS — translated */}
                <ul className={`nav-links ${menuOpen ? "open" : ""}`}>
                    <li><Link to="/"         onClick={() => setMenuOpen(false)}>{t.navLinks.home}</Link></li>
                    <li><Link to="/history"  onClick={() => setMenuOpen(false)}>{t.navLinks.heritage}</Link></li>
                    <li><Link to="/donation" onClick={() => setMenuOpen(false)}>{t.navLinks.donation}</Link></li>
                    <li><Link to="/gallery"  onClick={() => setMenuOpen(false)}>{t.navLinks.gallery}</Link></li>
                    <li><Link to="/contact"  onClick={() => setMenuOpen(false)}>{t.navLinks.contact}</Link></li>

                    {/* LANGUAGE DROPDOWN — translated labels */}
                    <li className="lang-dropdown">
                        <div
                            className="lang-selected"
                            onClick={() => setLangOpen(!langOpen)}
                        >
                            {language} ▾
                        </div>

                        {langOpen && (
                            <ul className="lang-menu">
                                <li onClick={() => handleLanguageChange("EN")}>{t.languages.EN}</li>
                                <li onClick={() => handleLanguageChange("TA")}>{t.languages.TA}</li>
                                <li onClick={() => handleLanguageChange("ML")}>{t.languages.ML}</li>
                            </ul>
                        )}
                    </li>
                </ul>

            </div>
        </nav>
    );
}