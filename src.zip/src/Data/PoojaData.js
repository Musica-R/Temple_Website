const poojaData = {
  EN: [
    {
      id: 1,
      name: "Bhagavathy Seva",
      icon: "🪔",
      price: "₹100",
      desc: "Special offering performed to Goddess Bhagavathy for blessings and protection."
    },
    {
      id: 2,
      name: "Chanting Ritual (Chanthattam)",
      icon: "📿",
      price: "₹50",
      desc: "Traditional chanting ritual invoking divine energy and positivity."
    },
    {
      id: 3,
      name: "First Rice Feeding (Choroonu)",
      icon: "👶",
      price: "₹25",
      desc: "Sacred ceremony marking a child's first intake of solid food."
    },
    {
      id: 4,
      name: "Lamp Offering (Chuttuvilakku)",
      icon: "🪔",
      price: "₹401",
      desc: "Lighting rows of lamps around the temple as an offering."
    },
    {
      id: 5,
      name: "Lamp Garland Offering (Niramala)",
      icon: "✨",
      price: "₹1000",
      desc: "Decorative lighting of lamps forming a divine illumination."
    },
    {
      id: 6,
      name: "Lamp Tower Lighting (Deepasthambham)",
      icon: "🔥",
      price: "₹200",
      desc: "Lighting the sacred lamp pillar in the temple."
    },
    {
      id: 7,
      name: "Ganapathy Homam",
      icon: "🔥",
      price: "₹70",
      desc: "Fire ritual dedicated to Lord Ganesha for removing obstacles."
    },
    {
      id: 8,
      name: "Jaggery Payasam (Kadum Payasam)",
      icon: "🍯",
      price: "₹70",
      desc: "Sweet offering made with jaggery and rice."
    },
    {
      id: 9,
      name: "Offering Bundle (Kettunira)",
      icon: "🎁",
      price: "₹10",
      desc: "Symbolic offering tied and presented to the deity."
    },
    {
      id: 10,
      name: "Mixed Payasam (Koottu Payasam)",
      icon: "🍮",
      price: "₹100",
      desc: "Combination of different payasams offered to the deity."
    },
    {
      id: 11,
      name: "Garland Offering (Maala)",
      icon: "🌸",
      price: "₹5",
      desc: "Flower garland offering to the deity."
    },
    {
      id: 12,
      name: "Garland Pooja (Maala Poojikkal)",
      icon: "🌼",
      price: "₹10",
      desc: "Ritual offering of garlands with prayers."
    },
    {
      id: 13,
      name: "Mandala Lamp Ritual",
      icon: "🪔",
      price: "₹300",
      desc: "Lamp lighting ritual during Mandala season."
    },
    {
      id: 14,
      name: "Navarathri Lamp Ritual",
      icon: "✨",
      price: "₹300",
      desc: "Special lamp offering during Navarathri festival."
    },
    {
      id: 15,
      name: "Ghee Payasam",
      icon: "🥣",
      price: "₹50",
      desc: "Sweet offering prepared with ghee."
    },
    {
      id: 16,
      name: "Ghee Lamp (Neyvilakku)",
      icon: "🪔",
      price: "₹10",
      desc: "Lighting a lamp using ghee."
    },
    {
      id: 17,
      name: "Full Day Pooja",
      icon: "🙏",
      price: "₹1251",
      desc: "Complete day-long pooja performed in the devotee's name."
    },
    {
      id: 18,
      name: "Milk Payasam",
      icon: "🥛",
      price: "₹60",
      desc: "Sweet offering made with milk and rice."
    },
    {
      id: 19,
      name: "Palm Jaggery Payasam",
      icon: "🍯",
      price: "₹30",
      desc: "Traditional sweet made with palm jaggery."
    },
    {
      id: 20,
      name: "Pushpanjali",
      icon: "🌸",
      price: "₹8",
      desc: "Offering of flowers with prayers."
    },
    {
      id: 21,
      name: "Raktha Pushpanjali",
      icon: "🌺",
      price: "₹10",
      desc: "Special red flower offering for divine blessings."
    },
    {
      id: 22,
      name: "Sooktha Pushpanjali",
      icon: "📿",
      price: "₹40",
      desc: "Pushpanjali performed with Vedic hymns."
    },
    {
      id: 23,
      name: "Thrimadhuram",
      icon: "🍬",
      price: "₹25",
      desc: "Offering made from three sweet ingredients."
    },
    {
      id: 24,
      name: "Three-time Daily Pooja",
      icon: "🛕",
      price: "₹251",
      desc: "Pooja performed three times in a day."
    },
    {
      id: 25,
      name: "Thulabharam",
      icon: "⚖️",
      price: "₹50",
      desc: "Offering equal to the devotee's weight."
    },
    {
      id: 26,
      name: "Firecracker Offering (Vedi)",
      icon: "🎆",
      price: "₹10",
      desc: "Traditional firecracker offering in temple rituals."
    }
  ],

  TA: [
    {
      id: 1,
      name: "பகவதி சேவை",
      icon: "🪔",
      price: "₹100",
      desc: "பகவதி அம்மனுக்கு அர்ப்பணிக்கும் சிறப்பு பூஜை."
    },
    {
      id: 2,
      name: "சாந்தாட்டம்",
      icon: "📿",
      price: "₹50",
      desc: "மந்திர ஜெபம் மூலம் தெய்வ அருள் பெறும் வழிபாடு."
    },
    {
      id: 3,
      name: "சோறுண்ணல்",
      icon: "👶",
      price: "₹25",
      desc: "குழந்தையின் முதல் அன்னபிராசனம் விழா."
    },
    {
      id: 4,
      name: "சுற்றுவிளக்கு",
      icon: "🪔",
      price: "₹401",
      desc: "கோவில் சுற்றிலும் விளக்கு ஏற்றும் வழிபாடு."
    },
    {
      id: 5,
      name: "நிரமாலை",
      icon: "✨",
      price: "₹1000",
      desc: "விளக்குகளால் அலங்கரிக்கும் சிறப்பு வழிபாடு."
    },
    {
      id: 7,
      name: "கணபதி ஹோமம்",
      icon: "🔥",
      price: "₹70",
      desc: "விநாயகருக்கான ஹோமம்."
    },
    {
      id: 20,
      name: "புஷ்பாஞ்சலி",
      icon: "🌸",
      price: "₹8",
      desc: "மலர் சமர்ப்பித்து செய்யும் பூஜை."
    }
  ],

  ML: [
    {
      id: 1,
      name: "ഭഗവതി സേവ",
      icon: "🪔",
      price: "₹100",
      desc: "ഭഗവതി ദേവിക്ക് സമർപ്പിക്കുന്ന പ്രത്യേക പൂജ."
    },
    {
      id: 2,
      name: "ചാന്താട്ടം",
      icon: "📿",
      price: "₹50",
      desc: "മന്ത്രോച്ചാരണത്തോടെ നടത്തുന്ന പൂജ."
    },
    {
      id: 3,
      name: "ചോറൂണു",
      icon: "👶",
      price: "₹25",
      desc: "കുഞ്ഞിന്റെ ആദ്യ അന്നഭക്ഷണ ചടങ്ങ്."
    },
    {
      id: 4,
      name: "ചുറ്റുവിളക്ക്",
      icon: "🪔",
      price: "₹401",
      desc: "ക്ഷേത്രം ചുറ്റി വിളക്ക് തെളിയിക്കൽ."
    },
    {
      id: 7,
      name: "ഗണപതി ഹോമം",
      icon: "🔥",
      price: "₹70",
      desc: "വിഘ്നങ്ങൾ നീക്കാൻ ഗണപതിക്ക് സമർപ്പിക്കുന്ന ഹോമം."
    },
    {
      id: 20,
      name: "പുഷ്പാഞ്ജലി",
      icon: "🌸",
      price: "₹8",
      desc: "പുഷ്പങ്ങൾ സമർപ്പിച്ച് നടത്തുന്ന പൂജ."
    }
  ]
};

export default poojaData;