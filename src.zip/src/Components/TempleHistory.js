import "../Stylesheet/TempleHistory.css";
import historyData from "../Data/historyData";
import { useEffect } from "react";
import { useLanguage } from "../Context/Languagecontext";

export default function TempleHistory() {
    const { language } = useLanguage();
    const data = historyData[language] || historyData["EN"];

    useEffect(() => {
        const blocks = document.querySelectorAll(".history-block");

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add("show");
                    }
                });
            },
            {
                threshold: 0.2
            }
        );

        blocks.forEach((el) => observer.observe(el));

        return () => observer.disconnect();
    }, [language]); // re-run observer when language changes

    return (
        <section className="history-wrapper">

            {/* ===== HEADING ===== */}
            <div className="history-heading">
                <h1>
                    {language === "ML" ? "ഞങ്ങളുടെ പുണ്യ പൈതൃകം" :
                     language === "TA" ? "எங்கள் புனித பாரம்பரியம்" :
                     "Our Sacred Heritage"}
                </h1>
                <div className="divider"></div>
                <p>
                    {language === "ML"
                        ? "ശ്രീകുരുംബ കാവിന്റെ ദൈവിക പൈതൃകം, പാരമ്പര്യങ്ങൾ, കാലാതീതമായ കഥകൾ എന്നിവ അന്വേഷിക്കുക"
                        : language === "TA"
                        ? "ஸ்ரீகுரும்பா காவின் தெய்வீக மரபு, பாரம்பரியங்கள் மற்றும் காலமற்ற கதைகளை கண்டறியுங்கள்"
                        : "Discover the divine legacy, traditions, and timeless stories of Sreekurumba Kaavu"}
                </p>
            </div>

            {/* ===== HISTORY BLOCKS ===== */}
            {data.map((item, index) => (
                <div
                    className={`history-block ${index % 2 !== 0 ? "reverse" : ""}`}
                    key={index}
                >

                    {/* IMAGE */}
                    <div className="history-image">
                        <img src={item.image} alt={item.title} />
                    </div>

                    {/* CONTENT */}
                    <div className="history-text">
                        <h2>{item.title}</h2>

                        {/* Highlight first paragraph */}
                        <p className="highlight">{item.content[0]}</p>

                        {/* Remaining paragraphs */}
                        <div className="history-extra">
                            {item.content.slice(1).map((para, i) => (
                                <p key={i}>{para}</p>
                            ))}
                        </div>
                    </div>

                </div>
            ))}

        </section>
    );
}