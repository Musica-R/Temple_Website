import poojaData from "../Data/PoojaData";
import "../Stylesheet/Pooja.css";
import { useLanguage } from "../Context/Languagecontext";

export default function Pooja() {

    const { language } = useLanguage();

    // ✅ Pick correct language data
    const data = poojaData[language] || poojaData["EN"];

    return (
        <section id="poojas">
            <div className="section-header">
                <div className="section-tag">
                    {language === "TA" ? "புனித காணிக்கைகள்" :
                        language === "ML" ? "പവിത്ര സമർപ്പണങ്ങൾ" :
                            "Sacred Offerings"}
                </div>

                <h2 className="section-title">
                    {language === "TA" ? "பூஜை சேவைகள்" :
                        language === "ML" ? "പൂജാ സേവനങ്ങൾ" :
                            "Pooja Services"}
                </h2>

                <p className="section-desc">
                    {language === "TA"
                        ? "பாரம்பரியத்துடன் நடைபெறும் தெய்வீக பூஜைகளை அனுபவிக்கவும்"
                        : language === "ML"
                            ? "ആചാരപരമായ ഭക്തിയോടെ നടത്തുന്ന പൂജകൾ അനുഭവിക്കുക"
                            : "Experience divine rituals performed with tradition and devotion"}
                </p>
            </div>

            <div className="pooja-scroll">
                {data.map((pooja) => (
                    <div className="pooja-card" key={pooja.id}>
                        <div className="icon-circle">{pooja.icon}</div>

                        <h3>{pooja.name}</h3>
                        <p>{pooja.desc}</p>

                        <div className="price">
                            {pooja.price}
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
}