import "../Stylesheet/Section.css";
import { useEffect, useRef } from "react";
import { useLanguage } from "../Context/Languagecontext";          // ← add
import translations from "../Json/datatranslation.json";              // ← add

export default function Section() {
  const sectionRef = useRef(null);
  const { language } = useLanguage();                              // ← add
  const t = translations.section[language] || translations.section["EN"]; // ← add

  useEffect(() => {
    const el = sectionRef.current;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const items = el.querySelectorAll(".slide-left, .slide-right");
            items.forEach((item, i) => {
              setTimeout(() => {
                item.classList.add("animate");
              }, i * 390);
            });
            observer.unobserve(el);
          }
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(el);
  }, []);

  return (
    <section id="about" ref={sectionRef}>
      <div className="about-container">

        <div className="about-grid">

          {/* ===== IMAGES ===== */}
          <div className="about-img-wrap">
            <div className="img main-img">
              <img src="/assets/img.jpg" alt="Main Temple" />
            </div>
            <div className="img img-left slide-left">
              <img src="/assets/vin.jpg" alt="Side" />
            </div>
            <div className="img img-bottom slide-left delay">
              <img src="/assets/siva4.jpg" alt="Temple Tower" />
            </div>
          </div>

          {/* ===== TEXT ===== */}
          <div className="about-content slide-right">

            <div className="section-header">
              <div className="section-tag">{t.tag}</div>
              <h2 className="section-title">
                {t.titlePre} <span>{t.titleHighlight}</span>
              </h2>
              <div className="gold-rule"></div>
            </div>

            <p className="section-desc">{t.p1}</p>
            <p className="section-desc">{t.p2}</p>

            <div className="about-facts">
              <div className="fact-item">
                <strong>{t.facts.location.label}</strong>
                <span>{t.facts.location.value}</span>
              </div>
              <div className="fact-item">
                <strong>{t.facts.deity.label}</strong>
                <span>{t.facts.deity.value}</span>
              </div>
              <div className="fact-item">
                <strong>{t.facts.phone.label}</strong>
                <span>{t.facts.phone.value}</span>
              </div>
              <div className="fact-item">
                <strong>{t.facts.mobile.label}</strong>
                <span>{t.facts.mobile.value}</span>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
}