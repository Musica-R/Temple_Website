import "../Stylesheet/Hero.css";
import { useLanguage } from "../Context/Languagecontext";
import translations from "../Json/Reachustranslations.json"; 

export default function Hero() {
    // ─── Pick the right language block ───────────────────────────────────────
    const { language } = useLanguage();
    const t = translations.hero[language] || translations.hero["EN"];

    return (
        <section className="hero">
            <img src="assets/background1.png" alt="temple" />
            <div className="hero-overlay"></div>
            <div className="hero-smoke"></div>
            <div className="hero-content">
                <div className="hero-om fade-down">ॐ</div>
                <div className="hero-divider fade-down delay-1"></div>

                {/* Title & subtitle — translated */}
                <h1 className="fade-up delay-2">
                    {t.title}
                    <span>{t.subtitle}</span>
                </h1>

                {/* Tagline — translated */}
                <p className="hero-subtitle fade-up delay-3">
                    {t.tagline}
                </p>

                {/* CTA buttons — translated */}
                <div className="hero-ctas fade-up delay-4">
                    <a href="#booking"  className="btn-gold">    {t.ctaPooja}    </a>
                    <a href="#donation" className="btn-outline">  {t.ctaDonation} </a>
                </div>
            </div>
        </section>
    );
}