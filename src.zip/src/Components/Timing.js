import timingsData from "../Data/TimingData";
import { useLanguage } from "../Context/Languagecontext";
import translations from "../Json/Timingtranslations.json";
import "../Stylesheet/Timing.css";
import { useEffect } from "react";

export default function Timing() {

    const { language } = useLanguage();
    const langKey = (language || "EN").toUpperCase();

    const t = translations?.timing?.[langKey] || translations?.timing?.["EN"];

    useEffect(() => {
        const items = document.querySelectorAll(".timeline-item");

        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        items.forEach((item, index) => {
                            setTimeout(() => {
                                item.classList.add("show");
                            }, index * 150); // 👈 stagger delay
                        });

                        observer.disconnect(); // run only once
                    }
                });
            },
            { threshold: 0.2 }
        );

        if (items.length > 0) {
            observer.observe(items[0]); // trigger when first item visible
        }

        return () => observer.disconnect();
    }, []);
    return (
        <section id="timings">
            <div className="section-header">
                <div className="section-tag">
                    {langKey === "TA" ? "தினசரி நேரம்" :
                        langKey === "ML" ? "ദിവസേന സമയക്രമം" :
                            "Daily Schedule"}
                </div>

                <h2 className="section-title">
                    {langKey === "TA" ? "கோவில் நேரங்கள் & பூஜைகள்" :
                        langKey === "ML" ? "ക്ഷേത്ര സമയങ്ങളും പൂജകളും" :
                            "Temple Timings & Rituals"}
                </h2>

                <p className="section-desc">{t.desc}</p>
                <div className="gold-rule"></div>
            </div>

            <div className="timeline-wrapper">
                {timingsData.map((block) => {
                    const Icon = block.icon;

                    return (
                        <div className="timeline-block" key={block.id}>
                            <div className="timeline-header">
                                <Icon className="session-icon" />
                                <h3>{t[block.session]}</h3>
                            </div>

                            <div className="timeline">
                                {block.events.map((item, index) => (
                                    <div className="timeline-item" key={index}>
                                        <div className="dot"></div>
                                        <div className="content">
                                            <span className="t-name">
                                                {t.events[item.key]}
                                            </span>
                                            <span className="t-time">
                                                {item.time}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    );
                })}
            </div>
        </section>
    );
}