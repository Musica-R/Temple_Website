import "../Stylesheet/Ticker.css";
import { useLanguage } from "../Context/Languagecontext";
import translations from "../Json/Timingtranslations.json";

export default function Ticker() {

    const { language } = useLanguage();
    const langKey = (language || "EN").toUpperCase();

    const t = translations?.ticker?.[langKey] || translations?.ticker?.["EN"];

    return (
        <div className="ticker-wrap">
            <div className="ticker">

                <span>{t.darshan}</span>
                <span>{t.evening}</span>
                <span>{t.prayer}</span>
                <span>{t.deeparadhana}</span>

                {/* loop */}
                <span>{t.darshan}</span>
                <span>{t.evening}</span>
                <span>{t.prayer}</span>
                <span>{t.deeparadhana}</span>

            </div>
        </div>
    );
}